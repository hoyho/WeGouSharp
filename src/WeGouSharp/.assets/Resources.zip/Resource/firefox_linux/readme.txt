please copy your firefox (all files) to this folder

and set config file (wegousharpsettings.json) value `"UseEmbededBrowser":true`